package tests;

import helpers.ConfigProvider;
import io.qameta.allure.Allure;
import io.restassured.http.ContentType;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.anyOf;
import static org.hamcrest.Matchers.equalTo;

public class DeleteTestByIdTest extends TestBase {

    @Test
    public void createAndDeleteTestById() {
        // 1️⃣ Логинимся и получаем SID
        String sid = Allure.step("Login and get SID", () ->
                given()
                        .baseUri(ConfigProvider.BASE_URL)
                        .contentType(ContentType.JSON)
                        .body("{\"email\": \"admin@skillchecker.tech\", \"password\": \"admin123\"}")
                        .when()
                        .post("/login")
                        .then()
                        .statusCode(200)
                        .extract().cookie("connect.sid")
        );

        // 2️⃣ Создаём новый тест и забираем ID
        int testId = Allure.step("Create new test", () ->
                given()
                        .baseUri(ConfigProvider.BASE_URL)
                        .contentType(ContentType.JSON)
                        .cookie("connect.sid", sid)
                        .body("{\"name\": \"Test for delete\"}")
                        .when()
                        .post("/tests")
                        .then()
                        .statusCode(201)
                        .extract().jsonPath().getInt("id")
        );

        // 3️⃣ Удаляем тест по ID (ожидаем 200 или 204)
        Allure.step("Delete test by ID", () ->
                given()
                        .baseUri(ConfigProvider.BASE_URL)
                        .cookie("connect.sid", sid)
                        .when()
                        .delete("/tests/" + testId)
                        .then()
                        .statusCode(anyOf(equalTo(200), equalTo(204)))
        );

        // 4️⃣ Проверяем, что тест больше не существует
        Allure.step("Check that deleted test returns 404", () ->
                given()
                        .baseUri(ConfigProvider.BASE_URL)
                        .cookie("connect.sid", sid)
                        .when()
                        .get("/tests/" + testId)
                        .then()
                        .statusCode(404)
                        .body("message", equalTo("Test not found"))
        );
    }
}