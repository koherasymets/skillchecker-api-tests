package tests;

import io.restassured.response.Response;
import io.restassured.module.jsv.JsonSchemaValidator;
import org.testng.annotations.Test;

import java.util.Map;

import static io.restassured.RestAssured.given;
import static specs.Specs.baseRequestSpec;
import static specs.Specs.responseSpec200;

public class    SampleTest extends TestBase {

    @Test(description = "Login and Get all tests with valid SID")
    public void loginAndGetAllTests() {

        // 1. Логинимся с логом и берём все cookies
        Response loginResponse = given()
                .spec(baseRequestSpec)
                .log().all() // лог запроса
                .body("{ \"email\": \"admin@skillchecker.tech\", \"password\": \"admin123\" }")
                .when()
                .post("/login")
                .then()
                .log().all() // лог ответа
                .statusCode(200)
                .extract()
                .response();

        // 2. Выведем все куки и возьмём connect.sid
        Map<String, String> cookies = loginResponse.getCookies();
        System.out.println("All cookies: " + cookies);

        String sid = cookies.get("connect.sid");
        System.out.println("Session ID: " + sid);

        // 3. GET с кукой connect.sid
        given()
                .spec(baseRequestSpec)
                .cookie("connect.sid", sid)
                .when()
                .get("/tests")
                .then()
                .log().all()
                .spec(responseSpec200)
                .body(JsonSchemaValidator.matchesJsonSchemaInClasspath("schemas/tests_response.json"));
    }
}