package tests;

import io.qameta.allure.*;
import io.restassured.module.jsv.JsonSchemaValidator;
import io.restassured.response.Response;
import org.testng.annotations.Test;

import java.util.Map;

import static io.restassured.RestAssured.given;
import static specs.Specs.baseRequestSpec;
import static specs.Specs.responseSpec200;

@Epic("Authentication API")
@Feature("Login + Get Tests Scenario")
@Owner("Konstantin")
@Link(name = "Skillchecker", url = "https://skillchecker.tech")
public class SampleTest extends TestBase {

    @Severity(SeverityLevel.BLOCKER)
    @Story("Login and fetch all tests with valid session")
    @Test(description = "Login and Get all tests with valid SID")
    public void loginAndGetAllTests() {

        // 1️⃣ Логин
        Response loginResponse = given()
                .spec(baseRequestSpec)
                .log().all()
                .body("{ \"email\": \"admin@skillchecker.tech\", \"password\": \"admin123\" }")
                .when()
                .post("/login")
                .then()
                .log().all()
                .statusCode(200)
                .extract()
                .response();

        // 2️⃣ Вытаскиваем cookies
        Map<String, String> cookies = loginResponse.getCookies();
        System.out.println("All cookies: " + cookies);

        String sid = cookies.get("connect.sid");
        System.out.println("Session ID: " + sid);

        // 3️⃣ Делаем GET с кукой SID
        given()
                .spec(baseRequestSpec)
                .cookie("connect.sid", sid)
                .when()
                .get("/tests")
                .then()
                .log().all()
                .spec(responseSpec200)
                .body(JsonSchemaValidator.matchesJsonSchemaInClasspath("schemas/tests_response.json"));
    }

}