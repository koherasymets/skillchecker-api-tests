package tests;

import io.qameta.allure.*;
import io.restassured.module.jsv.JsonSchemaValidator;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
import static specs.Specs.baseRequestSpec;
import static specs.Specs.responseSpec400;

@Epic("Authentication API")
@Feature("Negative Login Scenarios")
@Owner("Konstantin")
@Link(name = "Skillchecker", url = "https://skillchecker.tech")
public class AuthNegativeTests extends TestBase {

    @Severity(SeverityLevel.CRITICAL)
    @Story("Login with empty body")
    @Test(description = "Login with empty body should return 400")
    public void loginWithEmptyBody() {
        given()
                .spec(baseRequestSpec)
                .body("{}")
                .when()
                .post("/login")
                .then()
                .log().all()
                .spec(responseSpec400)
                .body("message", equalTo("Email and password are required"))
                .body(JsonSchemaValidator.matchesJsonSchemaInClasspath("schemas/error_response.json"));
    }

    @Severity(SeverityLevel.CRITICAL)
    @Story("Login with empty email")
    @Test(description = "Login with empty email should return 400")
    public void loginWithEmptyEmail() {
        String body = "{ \"email\": \"\", \"password\": \"admin123\" }";

        given()
                .spec(baseRequestSpec)
                .body(body)
                .when()
                .post("/login")
                .then()
                .log().all()
                .spec(responseSpec400)
                .body("message", equalTo("Email and password are required"))
                .body(JsonSchemaValidator.matchesJsonSchemaInClasspath("schemas/error_response.json"));
    }

    @Severity(SeverityLevel.CRITICAL)
    @Story("Login with empty password")
    @Test(description = "Login with empty password should return 400")
    public void loginWithEmptyPassword() {
        String body = "{ \"email\": \"admin@skillchecker.tech\", \"password\": \"\" }";

        given()
                .spec(baseRequestSpec)
                .body(body)
                .when()
                .post("/login")
                .then()
                .log().all()
                .spec(responseSpec400)
                .body("message", equalTo("Email and password are required"))
                .body(JsonSchemaValidator.matchesJsonSchemaInClasspath("schemas/error_response.json"));
    }

    @Severity(SeverityLevel.CRITICAL)
    @Story("Login with invalid credentials")
    @Test(description = "Login with invalid credentials should return 401")
    public void loginWithInvalidCredentials() {
        String body = "{ \"email\": \"wrong@skillchecker.tech\", \"password\": \"wrongpass\" }";

        given()
                .spec(baseRequestSpec)
                .body(body)
                .when()
                .post("/login")
                .then()
                .log().all()
                .statusCode(401)
                .body("message", equalTo("Invalid credentials"))
                .body(JsonSchemaValidator.matchesJsonSchemaInClasspath("schemas/error_response.json"));
    }

}