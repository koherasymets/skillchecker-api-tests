package tests;

import io.restassured.RestAssured;
import org.testng.annotations.BeforeClass;

import static specs.Specs.baseRequestSpec;

public class TestBase {

    @BeforeClass
    public void setup() {
        RestAssured.requestSpecification = baseRequestSpec;
    }

}