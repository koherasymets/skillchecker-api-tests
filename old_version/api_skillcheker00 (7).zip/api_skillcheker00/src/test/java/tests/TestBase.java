package tests;

public class TestBase {

}