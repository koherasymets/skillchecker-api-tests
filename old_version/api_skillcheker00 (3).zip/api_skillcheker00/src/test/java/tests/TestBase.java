package tests;

import io.qameta.allure.restassured.AllureRestAssured;
import org.testng.annotations.BeforeClass;

import static io.restassured.RestAssured.filters;

public class TestBase {
    @BeforeClass
    public void attachAllureFilter() {
        filters(new AllureRestAssured());
    }
}